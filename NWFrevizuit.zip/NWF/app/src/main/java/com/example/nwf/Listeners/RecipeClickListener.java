package com.example.nwf.Listeners;

public interface RecipeClickListener {
    void onRecipeClicked(String id);
}
