package com.example.nwf.Models;

public class Length {
    public int number;
    public String unit;
}
