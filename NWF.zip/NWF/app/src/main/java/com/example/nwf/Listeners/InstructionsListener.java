package com.example.nwf.Listeners;

import com.example.nwf.Models.InstructionsResponse;

public interface InstructionsListener {
    void didFetch(InstructionsResponse response, String message);
    void didError(String message);
}
